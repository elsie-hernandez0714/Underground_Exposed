Underground_Exposed
===================

Undergroun Exposed is an education mock blog dedicated to underground and local artists. 

Music and images belong to its rightful owners and are only used for educational purposes. 
